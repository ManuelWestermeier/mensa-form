function Select({ data, name, type, _ref, isDate, updateDate }) {
  return (
    <>
      <p htmlFor={name + "-select"}>{name}</p>
      <select
        onChange={(e) => {
          if (isDate) {
            updateDate((x) => !x);
          }
        }}
        ref={_ref}
        id={name + "-select"}
        className={`form-control ${type ?? ""}`}
      >
        {data.map((x) => (
          <option key={x}>{x}</option>
        ))}
      </select>
    </>
  );
}

export default Select;
