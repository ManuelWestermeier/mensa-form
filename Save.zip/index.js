const qs = require("querystring")
const { randomBytes } = require("crypto");
const { createServer } = require("./WSNET_Framework/_server");
const fs = require("fs");
const http = require("http")
const { log } = require("console");
const adminPassword = "adminium324"

const data = JSON.parse(fs.readFileSync("data.txt", "utf-8")) ?? {
    days: {
        "übermorgen": [],
        "gestern": [],
    },
    cathegories: {
        "übermorgen": {
            starter: ["Apfel", "Banane"],
            menu: ["Burger", "Schnitzel", "Mensch"],
            dessert: [
                "Kuchen",
                "Frosh",
                "Pfann Kuchen ",
            ],
        },
        "gestern": {
            starter: ["Tomate", "Gurke"],
            menu: ["Fuß", "Hendl"],
            dessert: [
                "YY",
                "Essen",
            ],
        },
    },
    ideas: [],
    admin: false
}

createServer({ port: 7777 }, async client => {
    //create the user and aut value
    var user = false;
    //on auth
    client.onGet("auth", data => {
        //check if the user is auth
        if (auth(data)) {
            //set the user to the sended username
            user = data.u
            //return sucsess
            return true;
        }
        //return error
        else return false;
    });
    //on get the dates
    client.onGet("dates", () => {
        if (!user) return false;
        return Object.keys(data.days);
    })
    //on get the cathegories
    client.onGet("cathegories", day => {
        if (!user) return false;
        if (!data.cathegories?.[day]) return false;
        return data.cathegories[day];
    })
    //get the statistic
    client.onGet("statistic", day => {
        if (!user) return false;
        if (!data.cathegories?.[day]) return false;
        return getStatisticData(day)
    })
    //on push idea
    client.onGet("add-idea", user_data => {
        if (!user) return;
        //reacte message
        const msg = {
            name: user_data?.name || "noname",
            idea: user_data?.idea ?? "no idea",
        };
        //push the idea
        data.ideas.unshift(msg);
        //if the admin is online notificate him
        if (data.admin) data.admin?.say?.("idea", msg);
    })
    //on create user
    client.onGet("create_new_user", () => createUser());
    //for ordering
    client.onGet("order", user_data => {
        //check if user is auth
        if (!user) return "!!!Du bist nicht angemeldet!!!";
        //check if the request include all params
        if (!user_data?.name) return "!!!error : nicht alle Parameter vegeben!!!";
        if (!user_data?.starter) return "!!!error : nicht alle Parameter vegeben!!!";
        if (!user_data?.menu) return "!!!error : nicht alle Parameter vegeben!!!";
        if (!user_data?.dessert) return "!!!error : nicht alle Parameter vegeben!!!";
        if (!user_data?.date) return "!!!error : nicht alle Parameter vegeben!!!";
        //check if the day exist
        if (!data.days?.[user_data.date]) return "!!!error : Datum ist nicht definiert!!!";
        //disable that the user can upload 2 orders
        data.days[user_data.date] = data.days[user_data.date].filter(it => it.user != user);
        //check if the cathegries are allowed
        /*
         if (!data.cathegories?.[user_data.date]?.starter?.includes?.(user_data.starter))
             return "!!!error : Kathegorie is nicht definiert!!!"
         if (!data.cathegories?.[user_data.date]?.manu?.includes?.(user_data.manu))
             return "!!!error : Kathegorie is nicht definiert!!!"
         if (!data.cathegories?.[user_data.date]?.dessert?.includes?.(user_data.dessert))
             return "!!!error : Kathegorie is nicht definiert!!!"
         */
        //push to the date the invest
        data.days[user_data.date].push({
            starter: user_data?.starter,
            main: user_data?.menu,
            dessert: user_data?.dessert,
            name: user_data?.name,
            user,
        })
        //send sucsess message
        return "Geschaft 👍 deine Bestellung wurde erfolgreich abgesendet"
    })

})

//get startistic data
function getStatisticData(date) {
    //get the length
    const userCount = data.days[date].length;
    //for starter
    var starter = {};
    data.cathegories[date].starter.forEach(c => starter[c] = 0);
    //fro menu
    var menu = {};
    data.cathegories[date].menu.forEach(c => menu[c] = 0);
    //for dessert
    var dessert = {};
    data.cathegories[date].dessert.forEach(c => dessert[c] = 0);

    data.days[date].forEach(((data) => {
        try {
            //set the starter
            starter[data.starter]++;
            //set the mein menu
            menu[data.main]++;
            //set the dessert
            dessert[data.dessert]++;
        } catch (error) {

        }
    }))

    return {
        userCount,
        starter,
        menu,
        dessert
    }
}

//menage authentication
function auth(data) {
    //check if the user and password is set
    if (!data?.u || !data?.p) return false;
    //create the file path
    const userPath = "user/" + securifyPath(data.u) + ".txt"
    //check if the user exists
    if (!fs.existsSync(userPath)) return false;
    //get the password from the user-file
    const password = fs.readFileSync(userPath, "utf-8");
    //return the user-password is equalt to the sended password
    return data?.p == password;

}

//create user

function createUser() {
    //create random userdata
    const userData = {
        u: securifyPath(randomBytes(10).toString("base64url")),
        p: randomBytes(30).toString("base64url")
    }
    //create the userfile path
    const userPath = "user/" + userData.u + ".txt"
    //check if the user not exists
    if (fs.existsSync(userPath)) return false;
    //store the userdata
    fs.writeFileSync(userPath, userData.p, "utf-8");

    return userData;

}

//securify paths
function securifyPath(str = "") {
    return str.split("/").join("_").split(".").join("_");
}

setInterval(() => {
    fs.writeFileSync("data.txt", JSON.stringify(data, false, 4), "utf-8");
}, 10000)

http.createServer((req, res) => {
    //split the url
    const { pathname, searchParams } = new URL("http://localhost" + req.url);
    //not auth
    if (searchParams.get("p") != adminPassword) {
        //set the content type
        res.writeHead(200, { "content-type": "text/html" })
        return res.end("<h1>not logged in</h1>")
    }

    if (req.method == "GET") {
        //set the content type
        res.writeHead(200, { "content-type": "text/html" })
        res.end(fs.readFileSync("admin.html", "utf-8"));
    }
    else if (req.method == "POST") {

        var body = ""

        req.on("data", chunk => {
            body += chunk.toString();
        });

        req.on("end", () => {
            //parse the admin_data
            var admin_data = {}
            try {
                admin_data = JSON.parse(body ?? "{}")
            } catch (error) { console.error(error) }
            //set the content type to json
            res.writeHead(200, { "content-type": "application/json" })

            //to get the days
            if (pathname == "/days") {
                res.end(JSON.stringify(Object.keys(data.days)))
            }
            //to get the ideas
            else if (pathname == "/ideas") {
                res.end(JSON.stringify(data.ideas))
            }
            //to add a day
            else if (pathname == "/addDay") {
                try {
                    data.days[admin_data?.day] = [];
                    data.cathegories[admin_data?.day] = {
                        starter: (admin_data?.starter + "" || "--").split("/"),
                        menu: (admin_data?.menu + "" || "--").split("/"),
                        dessert: (admin_data?.dessert + "" || "--").split("/"),
                    };
                    res.end("true")
                } catch (error) { res.end("false") }
            }
            //delete day
            else if (pathname == "/deleteDay") {
                //check if the admin post data includes delete_day
                if (!admin_data?.delete_day) return res.end('false')
                if (!data.cathegories?.[admin_data.delete_day]) return res.end('false')
                if (data.cathegories?.[admin_data.delete_day]) {
                    delete data.cathegories[admin_data.delete_day]
                    delete data.days[admin_data.delete_day]
                    res.end('true')
                }
            }
            //delete all ideas 
            else if (pathname == "/deleteIdeas") {
                data.ideas = []
                return res.end("true")
            }
            //return error
            else res.end('false')

        })

    }

}).listen(8288)